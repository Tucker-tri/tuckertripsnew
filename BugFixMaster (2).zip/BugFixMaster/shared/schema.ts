import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  profileImage: text("profile_image"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  profileImage: true,
}).extend({
  fullName: z.string().optional(),
  email: z.string().email().optional(),
  profileImage: z.string().url().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Categories enum
export const tripCategoryEnum = pgEnum("trip_category", [
  "vacation", "business", "adventure", "family", "other"
]);

// Trip table schema
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  destination: text("destination").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  category: text("category").notNull(), // vacation, business, adventure, family, other
  description: text("description"),
  imageUrl: text("image_url"), // URL to the image
  isPublic: boolean("is_public").default(false),
  isFutureTrip: boolean("is_future_trip").default(false),
  tripRating: integer("trip_rating"), // Overall trip rating (1-5)
  // Travel details
  airlineName: text("airline_name"),
  airlineCost: text("airline_cost"),
  airlineRating: integer("airline_rating"), // 1-5
  flightQuantity: text("flight_quantity"),
  airlineComments: text("airline_comments"),
  // Accommodation details
  accommodationType: text("accommodation_type"), // hotel, rental, etc.
  accommodationLink: text("accommodation_link"),
  accommodationCost: text("accommodation_cost"),
  accommodationRating: integer("accommodation_rating"), // 1-5
  otherAccommodationLinks: text("other_accommodation_links"),
  accommodationComments: text("accommodation_comments"),
  // Restaurant details
  restaurantTypes: text("restaurant_types"),
  restaurantNames: text("restaurant_names"),
  restaurantLinks: text("restaurant_links"),
  bestFood: text("best_food"),
  otherRestaurantOptions: text("other_restaurant_options"),
  restaurantRating: integer("restaurant_rating"), // 1-5
  restaurantComments: text("restaurant_comments"),
  // Transportation details
  rentalCarCompany: text("rental_car_company"),
  rentalCarCost: text("rental_car_cost"),
  rentalCarRating: integer("rental_car_rating"), // 1-5
  rentalCarQuality: text("rental_car_quality"),
  rentalCarComments: text("rental_car_comments"),
  otherTransportation: text("other_transportation"), // train, subway, etc.
  // Excursions details
  excursions: text("excursions"),
  weather: text("weather"),
  overallComment: text("overall_comment"),
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const tripCategories = ["vacation", "business", "adventure", "family", "other"] as const;

export const insertTripSchema = createInsertSchema(trips)
  .pick({
    destination: true,
    startDate: true,
    endDate: true,
    category: true,
    description: true,
    imageUrl: true,
    isPublic: true,
    isFutureTrip: true,
    tripRating: true,
    // Travel details
    airlineName: true,
    airlineCost: true,
    airlineRating: true,
    flightQuantity: true,
    airlineComments: true,
    // Accommodation details
    accommodationType: true,
    accommodationLink: true,
    accommodationCost: true,
    accommodationRating: true,
    otherAccommodationLinks: true,
    accommodationComments: true,
    // Restaurant details
    restaurantTypes: true,
    restaurantNames: true,
    restaurantLinks: true,
    bestFood: true,
    otherRestaurantOptions: true,
    restaurantRating: true,
    restaurantComments: true,
    // Transportation details
    rentalCarCompany: true,
    rentalCarCost: true,
    rentalCarRating: true,
    rentalCarQuality: true,
    rentalCarComments: true,
    otherTransportation: true,
    // Excursions details
    excursions: true,
    weather: true,
    overallComment: true,
  })
  .extend({
    category: z.enum(tripCategories),
    startDate: z.coerce.date(),
    endDate: z.coerce.date(),
    description: z.string().optional().nullable(),
    imageUrl: z.string().url().optional().nullable(),
    isPublic: z.boolean().optional().default(false),
    isFutureTrip: z.boolean().optional().default(false),
    tripRating: z.number().min(0).max(5).optional().nullable(),
    // Travel details
    airlineName: z.string().optional().nullable(),
    airlineCost: z.string().optional().nullable(),
    airlineRating: z.number().min(0).max(5).optional().nullable(),
    flightQuantity: z.string().optional().nullable(),
    airlineComments: z.string().optional().nullable(),
    // Accommodation details
    accommodationType: z.string().optional().nullable(),
    accommodationLink: z.string().optional().nullable(),
    accommodationCost: z.string().optional().nullable(),
    accommodationRating: z.number().min(0).max(5).optional().nullable(),
    otherAccommodationLinks: z.string().optional().nullable(),
    accommodationComments: z.string().optional().nullable(),
    // Restaurant details
    restaurantTypes: z.string().optional().nullable(),
    restaurantNames: z.string().optional().nullable(),
    restaurantLinks: z.string().optional().nullable(),
    bestFood: z.string().optional().nullable(),
    otherRestaurantOptions: z.string().optional().nullable(),
    restaurantRating: z.number().min(0).max(5).optional().nullable(),
    restaurantComments: z.string().optional().nullable(),
    // Transportation details
    rentalCarCompany: z.string().optional().nullable(),
    rentalCarCost: z.string().optional().nullable(),
    rentalCarRating: z.number().min(0).max(5).optional().nullable(),
    rentalCarQuality: z.string().optional().nullable(),
    rentalCarComments: z.string().optional().nullable(),
    otherTransportation: z.string().optional().nullable(),
    // Excursions details
    excursions: z.string().optional().nullable(),
    weather: z.string().optional().nullable(),
    overallComment: z.string().optional().nullable(),
  });

export const updateTripSchema = insertTripSchema.partial();

export type InsertTrip = z.infer<typeof insertTripSchema>;
export type UpdateTrip = z.infer<typeof updateTripSchema>;
export type Trip = typeof trips.$inferSelect;

// Set up relations
export const usersRelations = relations(users, ({ many }) => ({
  trips: many(trips),
}));

export const tripsRelations = relations(trips, ({ one }) => ({
  user: one(users, {
    fields: [trips.userId],
    references: [users.id],
  }),
}));
