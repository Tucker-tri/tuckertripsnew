import * as brevo from '@getbrevo/brevo';

// Check if Brevo API key is available
if (typeof process !== 'undefined' && !process.env.BREVO_API_KEY) {
  console.warn("BREVO_API_KEY is not set. Email functionality will be disabled.");
}

// Create API instance
const apiInstance = new brevo.TransactionalEmailsApi();

// Set API key if available (server-side only)
if (typeof process !== 'undefined') {
  apiInstance.setApiKey(brevo.TransactionalEmailsApiApiKeys.apiKey, process.env.BREVO_API_KEY || '');
}

interface EmailParams {
  to: string[];
  subject: string;
  htmlContent: string;
  sender?: {
    name: string;
    email: string;
  };
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    // Skip if API key is not available
    if (typeof process !== 'undefined' && !process.env.BREVO_API_KEY) {
      console.warn("Cannot send email: BREVO_API_KEY is not set");
      return false;
    }
    
    // Create a new email object
    const sendSmtpEmail = new brevo.SendSmtpEmail();
    
    // Set email parameters
    sendSmtpEmail.subject = params.subject;
    sendSmtpEmail.htmlContent = params.htmlContent;
    sendSmtpEmail.sender = params.sender || { 
      name: "TuckerTrips", 
      email: "noreply@tuckertrips.com" 
    };
    
    // Set recipients
    sendSmtpEmail.to = params.to.map(email => ({ email }));
    
    // Send the email
    await apiInstance.sendTransacEmail(sendSmtpEmail);
    return true;
  } catch (error) {
    console.error("Error sending email:", error);
    return false;
  }
}

// Function to generate HTML content for sharing a trip
export function generateTripEmailContent(tripData: any, sharerName: string = "A TuckerTrips user"): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(to right, #6d28d9, #4f46e5); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
        .content { padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px; }
        .trip-image { width: 100%; max-height: 300px; object-fit: cover; border-radius: 8px; }
        .btn { display: inline-block; background: #6d28d9; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
        .footer { margin-top: 20px; font-size: 12px; color: #777; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Trip Shared With You</h1>
        </div>
        <div class="content">
          <p>${sharerName} has shared a trip with you!</p>
          
          <h2>${tripData.destination || 'Exciting Destination'}</h2>
          
          ${tripData.imageUrl ? `<img src="${tripData.imageUrl}" alt="Trip Image" class="trip-image">` : ''}
          
          <p><strong>Date:</strong> ${formatDateRange(tripData.startDate, tripData.endDate)}</p>
          
          <p><strong>Category:</strong> ${tripData.category ? capitalizeFirstLetter(tripData.category) : 'Not specified'}</p>
          
          ${tripData.description ? `<p><strong>Description:</strong> ${tripData.description}</p>` : ''}
          
          <p>Want to see more details? Visit TuckerTrips to create your own account and start tracking your adventures!</p>
          
          <p><a href="https://tuckertrips.com" class="btn">Visit TuckerTrips</a></p>
        </div>
        <div class="footer">
          <p>This email was sent from TuckerTrips, a travel experience logging platform.</p>
          <p>If you didn't expect this email, you can safely ignore it.</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

// Helper function to format date range
function formatDateRange(startDate: string | Date, endDate: string | Date): string {
  const start = new Date(startDate);
  const end = new Date(endDate);
  
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
  return `${start.toLocaleDateString('en-US', options)} to ${end.toLocaleDateString('en-US', options)}`;
}

// Helper function to capitalize first letter
function capitalizeFirstLetter(string: string): string {
  return string.charAt(0).toUpperCase() + string.slice(1);
}