import { type User, type InsertUser, type Trip, type InsertTrip, type UpdateTrip, users, trips } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Trip methods
  getAllTrips(): Promise<Trip[]>;
  getTripsByUserId(userId: number): Promise<Trip[]>;
  getTripById(id: number): Promise<Trip | undefined>;
  createTrip(trip: InsertTrip & { userId: number }): Promise<Trip>;
  updateTrip(id: number, trip: UpdateTrip): Promise<Trip | undefined>;
  deleteTrip(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }
  
  // Trip Methods
  async getAllTrips(): Promise<Trip[]> {
    return db.select().from(trips).orderBy(desc(trips.createdAt));
  }
  
  async getTripsByUserId(userId: number): Promise<Trip[]> {
    return db.select().from(trips).where(eq(trips.userId, userId)).orderBy(desc(trips.createdAt));
  }
  
  async getTripById(id: number): Promise<Trip | undefined> {
    const result = await db.select().from(trips).where(eq(trips.id, id));
    return result[0];
  }
  
  async createTrip(insertTrip: InsertTrip & { userId: number }): Promise<Trip> {
    const result = await db.insert(trips).values(insertTrip).returning();
    return result[0];
  }
  
  async updateTrip(id: number, updateData: UpdateTrip): Promise<Trip | undefined> {
    if (Object.keys(updateData).length === 0) {
      return this.getTripById(id);
    }
    
    const result = await db
      .update(trips)
      .set({...updateData, updatedAt: new Date()})
      .where(eq(trips.id, id))
      .returning();
    
    return result[0];
  }
  
  async deleteTrip(id: number): Promise<boolean> {
    const result = await db.delete(trips).where(eq(trips.id, id)).returning();
    return result.length > 0;
  }
}

// Initialize with seed data if needed
const initializeDatabase = async () => {
  // Check if we have a demo user
  const existingUsers = await db.select().from(users).where(eq(users.username, "demo"));
  
  if (existingUsers.length === 0) {
    // Create a default user
    const [demoUser] = await db.insert(users).values({
      username: "demo",
      password: "password",
      fullName: "Demo User",
    }).returning();
    
    // Add some initial trips for the demo user
    const demoUserId = demoUser.id;
    
    // Sample trips
    await db.insert(trips).values([
      {
        userId: demoUserId,
        destination: "Paris, France",
        startDate: new Date("2023-06-12"),
        endDate: new Date("2023-06-18"),
        category: "vacation",
        description: "Explored the Louvre, Eiffel Tower, and enjoyed amazing pastries at local cafes.",
        imageUrl: "https://images.unsplash.com/photo-1581351721010-8cf859cb14a4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
      },
      {
        userId: demoUserId,
        destination: "Yellowstone National Park",
        startDate: new Date("2023-05-05"),
        endDate: new Date("2023-05-10"),
        category: "adventure",
        description: "Hiked through incredible geysers and spotted wildlife including bison and elk.",
        imageUrl: "https://images.unsplash.com/photo-1465778893808-9b3d1b443be4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
      },
      {
        userId: demoUserId,
        destination: "Tokyo, Japan",
        startDate: new Date("2023-04-02"),
        endDate: new Date("2023-04-08"),
        category: "business",
        description: "Attended tech conference while exploring Shibuya and Shinjuku in the evenings.",
        imageUrl: "https://images.unsplash.com/photo-1492571350019-22de08371fd3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
      }
    ]);
  }
};

// Create storage instance
export const storage = new DatabaseStorage();

// Initialize database with seed data (but don't block startup)
initializeDatabase().catch(error => {
  console.error("Error initializing database with seed data:", error);
});
