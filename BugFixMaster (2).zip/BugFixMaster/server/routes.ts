import express, { type Request, Response } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTripSchema, updateTripSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { sendEmail, generateTripEmailContent } from "./emailService";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();

  // Get all trips
  apiRouter.get("/trips", async (req: Request, res: Response) => {
    try {
      // In a real app, we would filter by the authenticated user's ID
      const userId = 1; // Demo user ID
      const trips = await storage.getTripsByUserId(userId);
      res.json(trips);
    } catch (error) {
      console.error("Error fetching trips:", error);
      res.status(500).json({ message: "Failed to fetch trips" });
    }
  });

  // Get trip by ID
  apiRouter.get("/trips/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid trip ID" });
      }
      
      const trip = await storage.getTripById(id);
      
      if (!trip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      res.json(trip);
    } catch (error) {
      console.error("Error fetching trip:", error);
      res.status(500).json({ message: "Failed to fetch trip" });
    }
  });

  // Create new trip
  apiRouter.post("/trips", async (req: Request, res: Response) => {
    try {
      // Validate request body
      const tripData = insertTripSchema.parse(req.body);
      
      // In a real app, we would get the user ID from the authenticated session
      const userId = 1; // Demo user ID
      
      const newTrip = await storage.createTrip({
        ...tripData,
        userId,
      });
      
      res.status(201).json(newTrip);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error creating trip:", error);
      res.status(500).json({ message: "Failed to create trip" });
    }
  });

  // Update trip
  apiRouter.patch("/trips/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid trip ID" });
      }
      
      // Validate request body
      const updateData = updateTripSchema.parse(req.body);
      
      const existingTrip = await storage.getTripById(id);
      
      if (!existingTrip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      // In a real app, we would check if the trip belongs to the authenticated user
      
      const updatedTrip = await storage.updateTrip(id, updateData);
      
      res.json(updatedTrip);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error updating trip:", error);
      res.status(500).json({ message: "Failed to update trip" });
    }
  });

  // Delete trip
  apiRouter.delete("/trips/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid trip ID" });
      }
      
      const existingTrip = await storage.getTripById(id);
      
      if (!existingTrip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      // In a real app, we would check if the trip belongs to the authenticated user
      
      const success = await storage.deleteTrip(id);
      
      if (success) {
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Failed to delete trip" });
      }
    } catch (error) {
      console.error("Error deleting trip:", error);
      res.status(500).json({ message: "Failed to delete trip" });
    }
  });

  // Get trip statistics
  apiRouter.get("/stats", async (req: Request, res: Response) => {
    try {
      // In a real app, we would filter by the authenticated user's ID
      const userId = 1; // Demo user ID
      const trips = await storage.getTripsByUserId(userId);
      
      // Calculate statistics
      const totalTrips = trips.length;
      
      // Count unique destinations
      const destinations = new Set(trips.map(trip => trip.destination)).size;
      
      // Calculate total days traveled
      let daysTraveled = 0;
      for (const trip of trips) {
        const start = new Date(trip.startDate);
        const end = new Date(trip.endDate);
        const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
        daysTraveled += days;
      }
      
      // Count trips by category
      const tripsByCategory: Record<string, number> = {};
      for (const trip of trips) {
        const category = trip.category;
        tripsByCategory[category] = (tripsByCategory[category] || 0) + 1;
      }
      
      res.json({
        totalTrips,
        destinations,
        daysTraveled,
        tripsByCategory
      });
    } catch (error) {
      console.error("Error fetching statistics:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Share trip via email
  apiRouter.post("/share-trip-email", async (req: Request, res: Response) => {
    try {
      const { tripData, recipientEmail } = req.body;
      
      if (!tripData || !recipientEmail) {
        return res.status(400).json({ message: "Trip data and recipient email are required" });
      }
      
      // Generate email content
      const htmlContent = generateTripEmailContent(tripData, "A TuckerTrips user");
      
      // Send the email
      const success = await sendEmail({
        to: [recipientEmail],
        subject: `Trip to ${tripData.destination} shared with you`,
        htmlContent,
      });
      
      if (success) {
        res.json({ message: "Trip shared successfully" });
      } else {
        res.status(500).json({ message: "Failed to share trip via email" });
      }
    } catch (error) {
      console.error("Error sharing trip via email:", error);
      res.status(500).json({ message: "Failed to share trip via email" });
    }
  });
  
  // Mount the API router
  app.use("/api", apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
