import React, { useState } from 'react';
import { User, Upload, Edit, MapPin, Calendar, Mail, Clock, Cake } from 'lucide-react';

const Profile = () => {
  const [coverPhoto, setCoverPhoto] = useState<string | null>(null);
  const [avatar, setAvatar] = useState<string | null>(null);
  const [bio, setBio] = useState<string>('Travel enthusiast exploring the world one trip at a time.');
  const [isEditingBio, setIsEditingBio] = useState(false);

  // Mock friends data
  const friends = [
    { id: 1, name: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?u=1' },
    { id: 2, name: 'Michael Chen', avatar: 'https://i.pravatar.cc/150?u=2' },
    { id: 3, name: 'Alexis Rodriguez', avatar: 'https://i.pravatar.cc/150?u=3' },
    { id: 4, name: 'Priya Patel', avatar: 'https://i.pravatar.cc/150?u=4' },
    { id: 5, name: 'James Wilson', avatar: 'https://i.pravatar.cc/150?u=5' },
  ];

  const handleCoverPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setCoverPhoto(imageUrl);
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setAvatar(imageUrl);
    }
  };

  const handleBioChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setBio(e.target.value);
  };

  const handleBioSave = () => {
    setIsEditingBio(false);
    // Here you would normally save to backend
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg shadow overflow-hidden">
      {/* Cover Photo Section */}
      <div className="relative h-64 bg-purple-100">
        {coverPhoto ? (
          <img 
            src={coverPhoto} 
            alt="Cover" 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-purple-500 to-indigo-600">
            <p className="text-white text-lg font-medium">Add a cover photo</p>
          </div>
        )}
        <label className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-md cursor-pointer hover:bg-gray-100">
          <Upload className="h-5 w-5 text-gray-600" />
          <input 
            type="file" 
            className="hidden" 
            accept="image/*" 
            onChange={handleCoverPhotoChange}
          />
        </label>
      </div>

      {/* Profile Info Section */}
      <div className="relative px-6 py-5">
        {/* Avatar */}
        <div className="absolute -top-16 left-6">
          <div className="relative w-32 h-32 rounded-full border-4 border-white bg-purple-200 overflow-hidden">
            {avatar ? (
              <img 
                src={avatar} 
                alt="Avatar" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-purple-600 text-white text-3xl font-bold">
                L
              </div>
            )}
            <label className="absolute bottom-0 right-0 bg-white p-1.5 rounded-full shadow cursor-pointer hover:bg-gray-100">
              <Edit className="h-4 w-4 text-gray-600" />
              <input 
                type="file" 
                className="hidden" 
                accept="image/*" 
                onChange={handleAvatarChange}
              />
            </label>
          </div>
        </div>

        {/* User Info */}
        <div className="ml-36 pt-2">
          <h1 className="text-2xl font-bold text-gray-800">Laviezah</h1>
          <p className="text-gray-600 flex items-center gap-1">
            <MapPin className="h-4 w-4" /> San Francisco, CA
          </p>
        </div>

        {/* Bio Section */}
        <div className="mt-8">
          <div className="flex justify-between items-start mb-2">
            <h2 className="text-lg font-semibold text-gray-800">About Me</h2>
            {!isEditingBio && (
              <button 
                onClick={() => setIsEditingBio(true)}
                className="text-purple-600 hover:text-purple-800 text-sm flex items-center"
              >
                <Edit className="h-4 w-4 mr-1" /> Edit
              </button>
            )}
          </div>
          
          {isEditingBio ? (
            <div className="space-y-2">
              <textarea
                value={bio}
                onChange={handleBioChange}
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                rows={4}
                placeholder="Tell us about yourself..."
              />
              <div className="flex justify-end space-x-2">
                <button 
                  onClick={() => setIsEditingBio(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleBioSave}
                  className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
                >
                  Save
                </button>
              </div>
            </div>
          ) : (
            <p className="text-gray-600">{bio}</p>
          )}
        </div>

        {/* Additional Info */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center text-gray-600">
            <Mail className="h-5 w-5 mr-2 text-gray-500" />
            <span>laviezah@example.com</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Calendar className="h-5 w-5 mr-2 text-gray-500" />
            <span>Joined April 2023</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Clock className="h-5 w-5 mr-2 text-gray-500" />
            <span>Last active today</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Cake className="h-5 w-5 mr-2 text-gray-500" />
            <span>Birthday: June 15</span>
          </div>
        </div>

        {/* Friends Section */}
        <div className="mt-10">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Friends on TuckerTrips</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {friends.map(friend => (
              <div key={friend.id} className="text-center">
                <div className="w-16 h-16 mx-auto rounded-full overflow-hidden border border-gray-200">
                  <img src={friend.avatar} alt={friend.name} className="w-full h-full object-cover" />
                </div>
                <p className="mt-2 text-sm font-medium text-gray-700">{friend.name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;