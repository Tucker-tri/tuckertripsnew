import { useQuery } from "@tanstack/react-query";
import { Trip } from "@shared/schema";
import { Link } from "wouter";
import StatCard from "@/components/StatCard";
import TripCard from "@/components/TripCard";

interface TripStats {
  totalTrips: number;
  destinations: number;
  daysTraveled: number;
  tripsByCategory: Record<string, number>;
}

const Dashboard = () => {
  // Fetch trips
  const { data: trips, isLoading: tripsLoading } = useQuery<Trip[]>({
    queryKey: ["/api/trips"],
  });

  // Fetch stats
  const { data: stats, isLoading: statsLoading } = useQuery<TripStats>({
    queryKey: ["/api/stats"],
  });

  // Define trip categories with images
  const tripCategories = [
    { 
      name: "Shared Trips", 
      image: "https://images.unsplash.com/photo-1528728935509-22fb14722a30?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fHJvYWQlMjB0cmlwfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60",
      href: "/shared-trips",
      borderColor: "border-pink-500"
    },
    { 
      name: "Future Trips", 
      image: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cm9hZCUyMHRyaXB8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60",
      href: "/trips?category=future",
      borderColor: "border-blue-500"
    },
    { 
      name: "My Trips", 
      image: "https://images.unsplash.com/photo-1506953823976-52e1fdc0149a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8dHJhdmVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60",
      href: "/trips",
      borderColor: "border-purple-500"
    },
    { 
      name: "New Trip Form", 
      image: "https://images.unsplash.com/photo-1537944434965-cf4679d1a598?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHRyYXZlbHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60",
      href: "/trips/add",
      borderColor: "border-green-500"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
      {tripCategories.map((category, index) => (
        <Link key={index} href={category.href}>
          <div className={`relative h-40 overflow-hidden rounded-xl shadow-md trip-card border-4 ${category.borderColor} cursor-pointer`}>
            <img 
              src={category.image} 
              alt={category.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
              <h3 className="text-white font-medium text-lg">{category.name}</h3>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default Dashboard;
