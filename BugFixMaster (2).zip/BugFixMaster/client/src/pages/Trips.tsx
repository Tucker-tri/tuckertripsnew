import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Trip, tripCategories } from "@shared/schema";
import { Link, useLocation } from "wouter";
import TripCard from "@/components/TripCard";
import DeleteModal from "@/components/DeleteModal";
import { formatDateForInput } from "@/lib/dateUtils";

const Trips = () => {
  const [, setLocation] = useLocation();
  const [filter, setFilter] = useState({
    category: "",
    destination: "",
    startDate: "",
    endDate: ""
  });
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [tripToDelete, setTripToDelete] = useState<number | null>(null);

  // Fetch trips
  const { data: trips, isLoading } = useQuery<Trip[]>({
    queryKey: ["/api/trips"],
  });

  // Delete trip mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/trips/${id}`);
      return id;
    },
    onSuccess: () => {
      // Invalidate trips query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    }
  });

  // Handle delete button click
  const handleDeleteClick = (id: number) => {
    setTripToDelete(id);
    setDeleteModalOpen(true);
  };

  // Handle confirm delete
  const handleConfirmDelete = () => {
    if (tripToDelete !== null) {
      deleteMutation.mutate(tripToDelete);
    }
  };

  // Handle edit button click
  const handleEditClick = (id: number) => {
    setLocation(`/trips/edit/${id}`);
  };

  // Filter trips
  const filteredTrips = trips?.filter(trip => {
    // Filter by category
    if (filter.category && trip.category !== filter.category) {
      return false;
    }
    
    // Filter by destination (case-insensitive contains)
    if (filter.destination && !trip.destination.toLowerCase().includes(filter.destination.toLowerCase())) {
      return false;
    }
    
    // Filter by start date
    if (filter.startDate) {
      const filterStartDate = new Date(filter.startDate);
      const tripStartDate = new Date(trip.startDate);
      if (tripStartDate < filterStartDate) {
        return false;
      }
    }
    
    // Filter by end date
    if (filter.endDate) {
      const filterEndDate = new Date(filter.endDate);
      const tripEndDate = new Date(trip.endDate);
      if (tripEndDate > filterEndDate) {
        return false;
      }
    }
    
    return true;
  });

  // Handle filter change
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilter(prev => ({ ...prev, [name]: value }));
  };

  // Reset filters
  const resetFilters = () => {
    setFilter({
      category: "",
      destination: "",
      startDate: "",
      endDate: ""
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800">My Trips</h2>
        <Link href="/trips/add">
          <a className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg flex items-center transition-colors">
            <i className="fas fa-plus mr-2"></i>
            Add Trip
          </a>
        </Link>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="category">
              Category
            </label>
            <select 
              id="category" 
              name="category" 
              value={filter.category}
              onChange={handleFilterChange}
              className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:border-primary"
            >
              <option value="">All Categories</option>
              {tripCategories.map(category => (
                <option key={category} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="destination">
              Destination
            </label>
            <input 
              type="text" 
              id="destination" 
              name="destination"
              value={filter.destination}
              onChange={handleFilterChange}
              placeholder="Search destinations" 
              className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:border-primary"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="startDate">
              From Date
            </label>
            <input 
              type="date" 
              id="startDate" 
              name="startDate"
              value={filter.startDate}
              onChange={handleFilterChange}
              className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:border-primary"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="endDate">
              To Date
            </label>
            <input 
              type="date" 
              id="endDate" 
              name="endDate"
              value={filter.endDate}
              onChange={handleFilterChange}
              className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:border-primary"
            />
          </div>
        </div>
        
        <div className="flex justify-end mt-4">
          <button 
            onClick={resetFilters}
            className="bg-white border border-slate-300 text-slate-700 font-medium py-2 px-4 rounded-lg hover:bg-slate-50 mr-2"
          >
            Reset
          </button>
          <button className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg">
            Apply Filters
          </button>
        </div>
      </div>
      
      {/* Trip List */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array(6).fill(0).map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
              <div className="h-40 bg-slate-200"></div>
              <div className="p-4">
                <div className="h-5 bg-slate-200 rounded w-3/4 mb-3"></div>
                <div className="h-4 bg-slate-200 rounded w-1/2 mb-3"></div>
                <div className="h-4 bg-slate-200 rounded w-full mb-3"></div>
                <div className="h-4 bg-slate-200 rounded w-5/6 mb-3"></div>
                <div className="flex justify-between">
                  <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                  <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : filteredTrips && filteredTrips.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTrips.map(trip => (
            <TripCard 
              key={trip.id} 
              trip={trip} 
              showActions={true}
              onEdit={handleEditClick}
              onDelete={handleDeleteClick}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          {trips && trips.length > 0 ? (
            <>
              <i className="fas fa-filter text-4xl text-slate-300 mb-4"></i>
              <h4 className="text-lg font-semibold text-slate-800 mb-2">No trips match your filters</h4>
              <p className="text-slate-600 mb-4">Try adjusting your search criteria</p>
              <button 
                onClick={resetFilters}
                className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg"
              >
                Clear Filters
              </button>
            </>
          ) : (
            <>
              <i className="fas fa-suitcase text-4xl text-slate-300 mb-4"></i>
              <h4 className="text-lg font-semibold text-slate-800 mb-2">No trips yet</h4>
              <p className="text-slate-600 mb-4">Start adding your travel experiences!</p>
              <Link href="/trips/add">
                <a className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg inline-flex items-center">
                  <i className="fas fa-plus mr-2"></i>
                  Add Your First Trip
                </a>
              </Link>
            </>
          )}
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      <DeleteModal 
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
};

export default Trips;
