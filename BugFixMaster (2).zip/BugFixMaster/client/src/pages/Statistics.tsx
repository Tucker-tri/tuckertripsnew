import { useQuery } from "@tanstack/react-query";
import StatCard from "@/components/StatCard";

interface TripStats {
  totalTrips: number;
  destinations: number;
  daysTraveled: number;
  tripsByCategory: Record<string, number>;
}

const Statistics = () => {
  // Fetch stats
  const { data: stats, isLoading } = useQuery<TripStats>({
    queryKey: ["/api/stats"],
  });

  // Calculate percentages for categories
  const calculatePercentage = (count: number, total: number) => {
    return total > 0 ? Math.round((count / total) * 100) : 0;
  };

  return (
    <div className="space-y-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Statistics</h2>
        <p className="text-slate-500">Overview of your travel history</p>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {isLoading ? (
          // Loading skeleton for stats
          Array(4).fill(0).map((_, i) => (
            <div key={i} className="bg-white p-4 rounded-lg shadow-md animate-pulse">
              <div className="flex items-center">
                <div className="rounded-full bg-slate-200 p-3 h-12 w-12 mr-4"></div>
                <div className="flex-1">
                  <div className="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
                  <div className="h-6 bg-slate-200 rounded w-1/4"></div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <>
            <StatCard 
              title="Total Trips" 
              value={stats?.totalTrips || 0} 
              icon="fa-suitcase" 
              color="primary" 
            />
            <StatCard 
              title="Destinations" 
              value={stats?.destinations || 0} 
              icon="fa-map-marker-alt" 
              color="secondary" 
            />
            <StatCard 
              title="Days Traveled" 
              value={stats?.daysTraveled || 0} 
              icon="fa-calendar-alt" 
              color="accent" 
            />
            <StatCard 
              title="Countries" 
              value={stats?.destinations || 0} // Using destinations as a proxy for countries
              icon="fa-plane" 
              color="success" 
            />
          </>
        )}
      </div>
      
      {/* Trip Categories Chart */}
      {isLoading ? (
        <div className="bg-white p-6 rounded-lg shadow-md animate-pulse">
          <div className="h-6 bg-slate-200 rounded w-1/6 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="h-64 flex items-center justify-center">
              <div className="h-48 w-48 rounded-full bg-slate-200"></div>
            </div>
            <div className="flex flex-col justify-center">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                    <div className="h-4 bg-slate-200 rounded w-1/6"></div>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-4">Trip Categories</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="h-64 flex items-center justify-center">
                {/* Simple pie chart visualization */}
                <div className="relative h-48 w-48">
                  {stats && stats.totalTrips > 0 ? (
                    Object.entries(stats.tripsByCategory).map(([category, count], index, array) => {
                      // Calculate the percentage for this category
                      const percentage = calculatePercentage(count, stats.totalTrips);
                      
                      // Calculate the accumulated percentage from previous segments
                      const previousPercentage = array
                        .slice(0, index)
                        .reduce((acc, [_, prevCount]) => acc + calculatePercentage(prevCount, stats.totalTrips), 0);
                      
                      // Get color for the category
                      const getCategoryColor = (cat: string) => {
                        switch (cat) {
                          case "vacation": return "#F59E0B"; // accent
                          case "business": return "#0D9488"; // primary
                          case "adventure": return "#0EA5E9"; // secondary
                          case "family": return "#10B981"; // success
                          default: return "#64748B"; // slate
                        }
                      };
                      
                      return (
                        <div 
                          key={category}
                          className="absolute inset-0 border-8 border-transparent rounded-full"
                          style={{
                            clipPath: `polygon(50% 50%, ${previousPercentage === 0 ? '0% 0%' : ''}, 
                            ${Array.from({ length: Math.ceil(percentage / 5) }, (_, i) => {
                              const angle = (previousPercentage + i * 5) * 3.6;
                              const x = 50 + 45 * Math.cos(angle * Math.PI / 180);
                              const y = 50 - 45 * Math.sin(angle * Math.PI / 180);
                              return `${x}% ${y}%`;
                            }).join(', ')})`,
                            borderTopColor: getCategoryColor(category),
                            borderRightColor: getCategoryColor(category),
                            borderBottomColor: getCategoryColor(category),
                            borderLeftColor: getCategoryColor(category),
                            transform: `rotate(${previousPercentage * 3.6}deg)`
                          }}
                        ></div>
                      );
                    })
                  ) : (
                    <div className="absolute inset-0 border-8 border-slate-200 rounded-full opacity-50"></div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center text-lg font-semibold">
                    {stats?.totalTrips || 0}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col justify-center">
              {stats && stats.totalTrips > 0 ? (
                Object.entries(stats.tripsByCategory).map(([category, count]) => {
                  const percentage = calculatePercentage(count, stats.totalTrips);
                  
                  // Get color class for the category
                  const getCategoryColorClass = (cat: string) => {
                    switch (cat) {
                      case "vacation": return "bg-accent";
                      case "business": return "bg-primary";
                      case "adventure": return "bg-secondary";
                      case "family": return "bg-success";
                      default: return "bg-slate-500";
                    }
                  };
                  
                  return (
                    <div key={category} className="mb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className={`w-3 h-3 rounded-full ${getCategoryColorClass(category)} mr-2`}></span>
                          <h4 className="font-medium capitalize">{category}</h4>
                        </div>
                        <div className="flex items-center">
                          <span className="font-semibold mr-1">{count}</span>
                          <span className="text-sm text-slate-500">{percentage}%</span>
                        </div>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                        <div 
                          className={`${getCategoryColorClass(category)} h-2 rounded-full`} 
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-6">
                  <p className="text-slate-500">No trip data available</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Trips Over Time */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">Trips Over Time</h3>
        <div className="h-64 relative">
          {isLoading ? (
            <div className="w-full h-48 bg-slate-100 rounded animate-pulse"></div>
          ) : (
            <>
              {/* Simple bar chart visualization */}
              <div className="absolute bottom-0 left-0 right-0 flex items-end justify-between h-48 px-2">
                {["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map((month, index) => {
                  // Random height for demo purposes - in a real app, this would be calculated from data
                  const height = stats && stats.totalTrips > 0 ? 
                    Math.floor(Math.random() * 90) + 10 : 
                    0;
                  
                  const isPast = index < new Date().getMonth();
                  
                  return (
                    <div key={month} className="flex flex-col items-center">
                      <div 
                        className={`w-10 ${isPast ? 'bg-primary' : 'bg-primary opacity-50'} rounded-t-md`} 
                        style={{ height: `${height}%` }}
                      ></div>
                      <span className="text-xs mt-2">{month}</span>
                    </div>
                  );
                })}
              </div>
              
              {/* Y-axis */}
              <div className="absolute top-0 bottom-0 left-0 flex flex-col justify-between text-xs text-slate-500 py-2">
                <span>10</span>
                <span>8</span>
                <span>6</span>
                <span>4</span>
                <span>2</span>
                <span>0</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Statistics;
