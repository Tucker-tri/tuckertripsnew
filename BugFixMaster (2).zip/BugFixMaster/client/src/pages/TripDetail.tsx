import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Trip } from "@shared/schema";
import { Link, useLocation, useParams, useRoute } from "wouter";
import { useState } from "react";
import DeleteModal from "@/components/DeleteModal";
import { formatDateRange, calculateDurationInDays } from "@/lib/dateUtils";
import { useToast } from "@/hooks/use-toast";

const TripDetail = () => {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const { toast } = useToast();

  // Fetch trip details
  const { data: trip, isLoading } = useQuery<Trip>({
    queryKey: [`/api/trips/${id}`],
  });

  // Delete trip mutation
  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/trips/${id}`);
      return id;
    },
    onSuccess: () => {
      // Invalidate trips query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      
      // Show success toast
      toast({
        title: "Success!",
        description: "Trip deleted successfully.",
      });
      
      // Redirect to trips page
      setLocation("/trips");
    },
    onError: (error) => {
      // Show error toast
      toast({
        title: "Error",
        description: `Failed to delete trip: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  });

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    deleteMutation.mutate();
  };

  // Calculate trip duration
  const getDuration = (start: Date, end: Date) => {
    return calculateDurationInDays(start, end);
  };

  // Format date for display
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Get category color
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "vacation": return "bg-accent";
      case "business": return "bg-primary";
      case "adventure": return "bg-secondary";
      case "family": return "bg-success";
      default: return "bg-slate-500";
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
        <div>
          <Link href="/trips">
            <a className="text-primary hover:text-primary/80 inline-flex items-center mb-2">
              <i className="fas fa-arrow-left mr-2"></i>
              Back to trips
            </a>
          </Link>
          <h2 className="text-2xl font-bold text-slate-800">
            {isLoading ? (
              <div className="h-8 bg-slate-200 rounded w-48 animate-pulse"></div>
            ) : (
              trip?.destination
            )}
          </h2>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={() => setLocation(`/trips/edit/${id}`)}
            className="bg-white border border-slate-300 text-slate-700 font-medium py-2 px-4 rounded-lg hover:bg-slate-50 flex items-center"
          >
            <i className="fas fa-edit mr-2"></i>
            Edit
          </button>
          <button 
            onClick={() => setDeleteModalOpen(true)}
            className="bg-danger hover:bg-danger/90 text-white font-medium py-2 px-4 rounded-lg flex items-center"
          >
            <i className="fas fa-trash mr-2"></i>
            Delete
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
          <div className="h-64 md:h-80 bg-slate-200"></div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="bg-slate-100 p-4 rounded-lg">
                  <div className="h-4 bg-slate-200 rounded w-1/3 mb-2"></div>
                  <div className="h-6 bg-slate-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
            <div className="mb-6">
              <div className="h-6 bg-slate-200 rounded w-1/6 mb-4"></div>
              <div className="h-4 bg-slate-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-slate-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-slate-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      ) : trip ? (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="h-64 md:h-80 bg-slate-200 relative">
            {trip.imageUrl ? (
              <img 
                src={trip.imageUrl} 
                alt={trip.destination} 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-slate-100">
                <i className="fas fa-mountain text-6xl text-slate-400"></i>
              </div>
            )}
            <span className={`absolute top-4 right-4 ${getCategoryColor(trip.category)} text-white text-sm font-medium px-3 py-1 rounded-full`}>
              {trip.category.charAt(0).toUpperCase() + trip.category.slice(1)}
            </span>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-500 mb-1">Dates</p>
                <p className="font-medium">{formatDateRange(new Date(trip.startDate), new Date(trip.endDate))}</p>
                <p className="text-sm text-slate-500 mt-1">
                  {getDuration(new Date(trip.startDate), new Date(trip.endDate))} days
                </p>
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-500 mb-1">Category</p>
                <p className="font-medium capitalize">{trip.category}</p>
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-500 mb-1">Added On</p>
                <p className="font-medium">{formatDate(new Date(trip.createdAt))}</p>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-slate-700">
                {trip.description || "No description provided."}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <i className="fas fa-exclamation-circle text-4xl text-danger mb-4"></i>
          <h4 className="text-lg font-semibold text-slate-800 mb-2">Trip not found</h4>
          <p className="text-slate-600 mb-4">The trip you are looking for might have been deleted or doesn't exist.</p>
          <Link href="/trips">
            <a className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg inline-flex items-center">
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Trips
            </a>
          </Link>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      <DeleteModal 
        isOpen={deleteModalOpen} 
        onClose={() => setDeleteModalOpen(false)} 
        onConfirm={handleDeleteConfirm}
      />
    </div>
  );
};

export default TripDetail;
