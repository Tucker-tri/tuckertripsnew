import { useQuery } from "@tanstack/react-query";
import { Trip } from "@shared/schema";
import { Link } from "wouter";

const SharedTrips = () => {
  // Fetch trips
  const { data: trips, isLoading } = useQuery<Trip[]>({
    queryKey: ["/api/trips"],
  });

  // Get a few trips to display as "shared"
  const sharedTrips = trips?.slice(0, 3);

  return (
    <div className="space-y-8">
      <div className="flex items-center mb-6">
        <div className="bg-primary bg-opacity-10 text-primary p-2 rounded-md mr-3">
          <i className="fas fa-users"></i>
        </div>
        <h2 className="text-xl font-bold text-slate-800">Shared Trips</h2>
        
        <div className="ml-auto">
          <Link href="/">
            <a className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg">
              Go Back
            </a>
          </Link>
        </div>
      </div>
      
      {isLoading ? (
        <div className="space-y-4">
          {Array(3).fill(0).map((_, i) => (
            <div key={i} className="bg-white p-4 rounded-lg shadow-md animate-pulse w-full">
              <div className="flex items-start">
                <div className="h-12 w-12 bg-slate-200 rounded-full mr-4"></div>
                <div className="flex-1">
                  <div className="h-5 bg-slate-200 rounded w-1/3 mb-2"></div>
                  <div className="h-4 bg-slate-200 rounded w-2/3 mb-2"></div>
                  <div className="h-24 bg-slate-200 rounded w-full mt-3"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : sharedTrips && sharedTrips.length > 0 ? (
        <div className="space-y-4">
          {sharedTrips.map((trip) => (
            <div key={trip.id} className="bg-white p-4 rounded-lg shadow-md w-full">
              <div className="flex items-start">
                <div className="h-12 w-12 bg-slate-200 rounded-full mr-4 overflow-hidden">
                  <img src="https://i.pravatar.cc/100" alt="User avatar" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-lg">{trip.destination}</h3>
                  <p className="text-sm text-slate-500">Shared by Corynn Thompson</p>
                  
                  {trip.imageUrl && (
                    <div className="mt-3 rounded-lg overflow-hidden h-48">
                      <img 
                        src={trip.imageUrl || "https://images.unsplash.com/photo-1500835556837-99ac94a94552"}
                        alt={trip.destination}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  
                  <p className="mt-3 text-slate-700">{trip.description || `Trip to ${trip.destination} from ${new Date(trip.startDate).toLocaleDateString()} to ${new Date(trip.endDate).toLocaleDateString()}`}</p>
                  
                  <div className="mt-4 flex justify-between items-center">
                    <div className="flex space-x-2">
                      <button className="text-slate-500 hover:text-primary">
                        <i className="far fa-heart mr-1"></i> Like
                      </button>
                      <button className="text-slate-500 hover:text-primary">
                        <i className="far fa-comment mr-1"></i> Comment
                      </button>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500">{new Date(trip.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <i className="fas fa-users text-4xl text-slate-300 mb-4"></i>
          <h4 className="text-lg font-semibold text-slate-800 mb-2">No shared trips yet</h4>
          <p className="text-slate-600 mb-4">When friends share trips with you, they'll appear here</p>
        </div>
      )}
    </div>
  );
};

export default SharedTrips;