import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { insertTripSchema, tripCategories, InsertTrip } from "@shared/schema";
import { useLocation } from "wouter";
import { formatDateForInput } from "@/lib/dateUtils";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle } from "lucide-react";
import MarkdownEditor from "../components/MarkdownEditor";

// Email validation regex
const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

// Function to check if Brevo API Key is available
const hasBrevoApiKey = import.meta.env.BREVO_API_KEY !== undefined;

const StarRating = ({ value, onChange }: { value: number | null, onChange: (val: number) => void }) => {
  return (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => onChange(star)}
          className="focus:outline-none"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill={value && star <= value ? "#6d28d9" : "none"}
            stroke={value && star <= value ? "#6d28d9" : "#d1d5db"}
            className="w-6 h-6"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.5"
              d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z"
            />
          </svg>
        </button>
      ))}
    </div>
  );
};

// Simple WYSIWYG toolbar component
const WysiwygToolbar = ({ textareaId }: { textareaId: string }) => {
  const applyTextFormat = (format: string) => {
    const textarea = document.getElementById(textareaId) as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    let formattedText = '';
    
    switch (format) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'underline':
        formattedText = `_${selectedText}_`;
        break;
      default:
        formattedText = selectedText;
    }
    
    // Replace the selected text with the formatted text
    const newText = textarea.value.substring(0, start) + formattedText + textarea.value.substring(end);
    textarea.value = newText;
    
    // Update the form value
    const event = new Event('input', { bubbles: true });
    textarea.dispatchEvent(event);
    
    // Set the selection to after the inserted formatting
    textarea.focus();
    textarea.setSelectionRange(start + formattedText.length, start + formattedText.length);
  };

  return (
    <div className="flex items-center space-x-1 border-b border-gray-200 p-1 bg-gray-50 rounded-t-md">
      <button 
        type="button" 
        className="p-1 hover:bg-gray-200 rounded"
        title="Warning"
      >
        <AlertTriangle className="h-4 w-4 text-amber-500" />
      </button>
      <div className="border-r border-gray-300 h-6 mx-1"></div>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-200 rounded font-bold"
        onClick={() => applyTextFormat('bold')}
        title="Bold"
      >
        B
      </button>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-200 rounded italic"
        onClick={() => applyTextFormat('italic')}
        title="Italic"
      >
        I
      </button>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-200 rounded underline"
        onClick={() => applyTextFormat('underline')}
        title="Underline"
      >
        U
      </button>
      <button type="button" className="p-1 hover:bg-gray-200 rounded" title="Heading">
        #
      </button>
      <div className="border-r border-gray-300 h-6 mx-1"></div>
      <button type="button" className="p-1 hover:bg-gray-200 rounded text-xs" title="Font Size">
        14 ▼
      </button>
      <div className="border-r border-gray-300 h-6 mx-1"></div>
      <button type="button" className="p-1 hover:bg-gray-200 rounded" title="Bullet List">
        •
      </button>
      <button type="button" className="p-1 hover:bg-gray-200 rounded" title="Numbered List">
        1.
      </button>
      <button type="button" className="p-1 hover:bg-gray-200 rounded" title="Checkbox">
        [ ]
      </button>
      <div className="border-r border-gray-300 h-6 mx-1"></div>
      <button type="button" className="p-1 hover:bg-gray-200 rounded" title="Link">
        🔗
      </button>
    </div>
  );
};

// Restaurant row component for dynamic adding
const RestaurantRow = ({ 
  onRemove, 
  index,
  register
}: { 
  onRemove: () => void, 
  index: number,
  register: any
}) => {
  return (
    <div className="flex items-center space-x-2 mt-2">
      <input
        type="text"
        placeholder="Restaurant Name"
        className="w-1/2 border border-slate-300 rounded-lg p-2"
        {...register(`restaurantName_${index}`)}
      />
      <input
        type="text"
        placeholder="Restaurant Link"
        className="w-1/2 border border-slate-300 rounded-lg p-2"
        {...register(`restaurantLink_${index}`)}
      />
      <button
        type="button"
        onClick={onRemove}
        className="bg-purple-600 text-white rounded-md p-2"
      >
        +
      </button>
    </div>
  );
};

const AddTrip = () => {
  const [, setLocation] = useLocation();
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("main");
  const [tripType, setTripType] = useState<"taken" | "future">("taken");
  const [sharing, setSharing] = useState<boolean>(false);
  const [shareEmail, setShareEmail] = useState<string>("");
  const [emailValid, setEmailValid] = useState<boolean>(true);
  const [restaurants, setRestaurants] = useState<number[]>([0]); // Start with one restaurant row
  const { toast } = useToast();

  // Setup form with validation
  const { 
    register, 
    handleSubmit, 
    formState: { errors, isSubmitting },
    reset,
    watch,
    setValue,
  } = useForm<InsertTrip>({
    resolver: zodResolver(insertTripSchema),
    defaultValues: {
      destination: "",
      category: undefined,
      startDate: new Date(),
      endDate: new Date(),
      description: "",
      imageUrl: "",
      isPublic: false,
      isFutureTrip: false,
    }
  });

  // Watch start and end dates for validation
  const startDate = watch("startDate");
  const endDate = watch("endDate");

  // Create trip mutation
  const createTripMutation = useMutation({
    mutationFn: async (data: InsertTrip) => {
      // If sharing via email and we have a valid email
      if (sharing && shareEmail && emailRegex.test(shareEmail)) {
        // Set isPublic to true if sharing
        data.isPublic = true;
        
        // We would send email here if Brevo API key is available
        if (hasBrevoApiKey) {
          try {
            await apiRequest("POST", "/api/share-trip-email", { 
              tripData: data,
              recipientEmail: shareEmail 
            });
          } catch (error) {
            console.error("Failed to send email:", error);
            // Continue with trip creation even if email fails
          }
        }
      }
      
      const res = await apiRequest("POST", "/api/trips", data);
      return res.json();
    },
    onSuccess: () => {
      // Invalidate trips query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      
      // Show success toast
      toast({
        title: "Success!",
        description: "Your trip has been added successfully." + 
          (sharing && shareEmail ? " Trip has been shared." : ""),
      });
      
      // Redirect to trips page
      setLocation("/trips");
    },
    onError: (error) => {
      // Show error toast
      toast({
        title: "Error",
        description: `Failed to add trip: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  });

  // Handle form submission
  const onSubmit = async (data: InsertTrip) => {
    // Set isFutureTrip based on the selected trip type
    data.isFutureTrip = tripType === "future";
    
    // Handle special trip type
    if (tripType === "future") {
      data.isFutureTrip = true;
    }
    
    // Set sharing status
    if (sharing) {
      data.isPublic = true;
    }
    
    // Collect restaurant data
    const restaurantNames: string[] = [];
    const restaurantLinks: string[] = [];
    
    restaurants.forEach((_, index) => {
      const nameKey = `restaurantName_${index}`;
      const linkKey = `restaurantLink_${index}`;
      
      // @ts-ignore - these are dynamic form fields
      const name = data[nameKey];
      // @ts-ignore
      const link = data[linkKey];
      
      if (name) {
        restaurantNames.push(name);
        restaurantLinks.push(link || "");
        
        // @ts-ignore - remove these properties as they're not in our schema
        delete data[nameKey];
        // @ts-ignore
        delete data[linkKey];
      }
    });
    
    // Add collected restaurant data to the form data
    data.restaurantNames = restaurantNames.length > 0 ? restaurantNames.join(",") : undefined;
    data.restaurantLinks = restaurantLinks.length > 0 ? restaurantLinks.join(",") : undefined;
    
    createTripMutation.mutate(data);
  };

  // Handle cancel button
  const handleCancel = () => {
    reset();
    setLocation("/trips");
  };

  // Handle image preview
  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    if (url) {
      setImagePreview(url);
    } else {
      setImagePreview(null);
    }
  };
  
  // Add a new restaurant row
  const addRestaurantRow = () => {
    setRestaurants([...restaurants, restaurants.length]);
  };
  
  // Remove a restaurant row
  const removeRestaurantRow = (index: number) => {
    setRestaurants(restaurants.filter((_, i) => i !== index));
  };
  
  // Handle sharing toggle
  const handleSharingToggle = (share: boolean) => {
    setSharing(share);
    if (!share) {
      setShareEmail("");
      setValue("isPublic", false);
    } else {
      setValue("isPublic", true);
    }
  };
  
  // Validate email
  const validateEmail = (email: string) => {
    const isValid = emailRegex.test(email);
    setEmailValid(isValid);
    return isValid;
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Create Trip</h2>
        </div>
        <div className="flex space-x-2">
          <button
            type="button"
            className={`px-4 py-2 rounded-md ${
              tripType === "taken" 
                ? "bg-purple-600 text-white" 
                : "bg-gray-200 text-gray-700"
            }`}
            onClick={() => setTripType("taken")}
          >
            My Trips Taken
          </button>
          <button
            type="button"
            className={`px-4 py-2 rounded-md ${
              tripType === "future" 
                ? "bg-purple-600 text-white" 
                : "bg-gray-200 text-gray-700"
            }`}
            onClick={() => setTripType("future")}
          >
            Future Trip
          </button>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-md">
        <Tabs defaultValue="main" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 flex space-x-2 border-b border-gray-200 w-full bg-transparent">
            <TabsTrigger 
              value="main" 
              className={`px-4 py-2 ${activeTab === 'main' ? 'border-b-2 border-purple-600 text-purple-600 font-medium' : 'text-gray-500'}`}
            >
              Basic Information
            </TabsTrigger>
            <TabsTrigger 
              value="travel" 
              className={`px-4 py-2 ${activeTab === 'travel' ? 'border-b-2 border-purple-600 text-purple-600 font-medium' : 'text-gray-500'}`}
            >
              Travel Details
            </TabsTrigger>
            <TabsTrigger 
              value="accommodation" 
              className={`px-4 py-2 ${activeTab === 'accommodation' ? 'border-b-2 border-purple-600 text-purple-600 font-medium' : 'text-gray-500'}`}
            >
              Accommodation
            </TabsTrigger>
            <TabsTrigger 
              value="dining" 
              className={`px-4 py-2 ${activeTab === 'dining' ? 'border-b-2 border-purple-600 text-purple-600 font-medium' : 'text-gray-500'}`}
            >
              Dining
            </TabsTrigger>
            <TabsTrigger 
              value="transportation" 
              className={`px-4 py-2 ${activeTab === 'transportation' ? 'border-b-2 border-purple-600 text-purple-600 font-medium' : 'text-gray-500'}`}
            >
              Transportation
            </TabsTrigger>
            <TabsTrigger 
              value="activities" 
              className={`px-4 py-2 ${activeTab === 'activities' ? 'border-b-2 border-purple-600 text-purple-600 font-medium' : 'text-gray-500'}`}
            >
              Activities
            </TabsTrigger>
          </TabsList>
          
          <form id="add-trip-form" className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
            <TabsContent value="main" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="destination" className="block text-sm font-medium text-slate-700 mb-1">
                    Trip Name <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="text" 
                    id="destination" 
                    placeholder="Enter your trip name"
                    className={`w-full border ${errors.destination ? 'border-red-500' : 'border-slate-300'} rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500`}
                    {...register("destination")}
                  />
                  {errors.destination && (
                    <div className="text-red-500 text-sm mt-1">{errors.destination.message}</div>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="startDate" className="block text-sm font-medium text-slate-700 mb-1">
                      Trip Start Date <span className="text-red-500">*</span>
                    </label>
                    <input 
                      type="date" 
                      id="startDate" 
                      className={`w-full border ${errors.startDate ? 'border-red-500' : 'border-slate-300'} rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500`}
                      {...register("startDate")}
                    />
                    {errors.startDate && (
                      <div className="text-red-500 text-sm mt-1">{errors.startDate.message}</div>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="endDate" className="block text-sm font-medium text-slate-700 mb-1">
                      Trip End Date <span className="text-red-500">*</span>
                    </label>
                    <input 
                      type="date" 
                      id="endDate" 
                      className={`w-full border ${errors.endDate ? 'border-red-500' : 'border-slate-300'} rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500`}
                      {...register("endDate")}
                    />
                    {errors.endDate && (
                      <div className="text-red-500 text-sm mt-1">{errors.endDate.message}</div>
                    )}
                    {startDate && endDate && new Date(endDate) < new Date(startDate) && (
                      <div className="text-red-500 text-sm mt-1">End date must be after start date</div>
                    )}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="destination" className="block text-sm font-medium text-slate-700 mb-1">
                    Location <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="text" 
                    placeholder="Enter your location"
                    className={`w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500`}
                    {...register("destination")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Overall Trip Rating
                  </label>
                  <StarRating 
                    value={watch("tripRating") || 0}
                    onChange={(val) => setValue("tripRating", val)}
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-1">
                    Trip Description
                  </label>
                  <MarkdownEditor
                    id="description"
                    value={watch("description") || ""}
                    onChange={(val) => setValue("description", val)}
                    placeholder="Share some details about your trip..."
                    rows={6}
                  />
                  {errors.description && (
                    <div className="text-red-500 text-sm mt-1">{errors.description.message}</div>
                  )}
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Cover Photo
                  </label>
                  <div className="flex items-center space-x-2">
                    <label className="cursor-pointer bg-gray-200 hover:bg-gray-300 transition-colors text-gray-700 py-2 px-4 rounded-md">
                      Choose File
                      <input
                        type="file"
                        className="hidden"
                        onChange={(e) => {
                          // This is just for UI, we'd need to use a file upload service in a real app
                          const file = e.target.files?.[0];
                          if (file) {
                            const fakeUrl = URL.createObjectURL(file);
                            setImagePreview(fakeUrl);
                            setValue("imageUrl", `https://example.com/${file.name}`);
                          }
                        }}
                      />
                    </label>
                    <span className="text-sm text-gray-500">No file chosen</span>
                  </div>
                  
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Trip Images (Up to 10 images)
                    </label>
                    <div className="flex items-center space-x-2">
                      <label className="cursor-pointer bg-gray-200 hover:bg-gray-300 transition-colors text-gray-700 py-2 px-4 rounded-md">
                        Choose Files
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const files = e.target.files;
                            if (files) {
                              // Limit to 10 images
                              const fileArray = Array.from(files).slice(0, 10);
                              
                              // For demo purposes, just use the first image as preview
                              if (fileArray.length > 0) {
                                const previewUrl = URL.createObjectURL(fileArray[0]);
                                setImagePreview(previewUrl);
                                setValue("imageUrl", previewUrl);
                              }
                              
                              // Show a toast with count of selected images
                              toast({
                                title: "Images selected",
                                description: `${fileArray.length} image${fileArray.length !== 1 ? 's' : ''} selected.`,
                              });
                            }
                          }}
                        />
                      </label>
                      <span className="text-sm text-gray-500">
                        {imagePreview ? "Images selected" : "No file chosen"}
                      </span>
                    </div>
                  </div>
                  
                  {imagePreview && (
                    <div className="mt-4">
                      <img 
                        src={imagePreview} 
                        alt="Trip preview" 
                        className="h-32 object-cover rounded"
                        onError={() => setImagePreview(null)}
                      />
                    </div>
                  )}
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Weather
                  </label>
                  <input 
                    type="text" 
                    placeholder="Weather"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("weather")}
                  />
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <div>
                  {/* Sharing options */}
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={sharing}
                        onChange={(e) => handleSharingToggle(e.target.checked)}
                        className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Share this trip</span>
                    </label>
                    
                    {sharing && (
                      <div className="flex items-center space-x-2">
                        <input
                          type="email"
                          value={shareEmail}
                          onChange={(e) => {
                            setShareEmail(e.target.value);
                            validateEmail(e.target.value);
                          }}
                          placeholder="Email address"
                          className={`border ${emailValid ? 'border-gray-300' : 'border-red-500'} rounded-md p-1 text-sm`}
                        />
                        <div className="flex space-x-2">
                          <button
                            type="button"
                            disabled={!emailValid || !shareEmail}
                            className={`text-xs px-2 py-1 rounded ${
                              emailValid && shareEmail 
                                ? 'bg-purple-600 text-white' 
                                : 'bg-gray-200 text-gray-500'
                            }`}
                          >
                            Email
                          </button>
                          <button
                            type="button"
                            className="text-xs px-2 py-1 rounded bg-blue-600 text-white"
                          >
                            Social
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => setActiveTab("travel")}
                    className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                  >
                    Next
                  </button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="travel" className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Airline Rating
                  </label>
                  <StarRating 
                    value={watch("airlineRating") || 0}
                    onChange={(val) => setValue("airlineRating", val)}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Airline Name
                  </label>
                  <input 
                    type="text" 
                    placeholder="Airline Name"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("airlineName")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Airline Cost $
                  </label>
                  <input 
                    type="text" 
                    placeholder="Airline Cost $"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("airlineCost")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Quantity of Flights
                  </label>
                  <input 
                    type="text" 
                    placeholder="Quantity of Flights"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("flightQuantity")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Overall Airline Comments
                  </label>
                  <textarea 
                    rows={4}
                    placeholder="Overall Airline Comments"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("airlineComments")}
                  ></textarea>
                </div>
              </div>
              
              <div className="flex justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab("main")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("accommodation")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Next
                </button>
              </div>
            </TabsContent>
            
            <TabsContent value="accommodation" className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Accommodation Rating
                  </label>
                  <StarRating 
                    value={watch("accommodationRating") || 0}
                    onChange={(val) => setValue("accommodationRating", val)}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Accommodation Type (hotel, rental, etc.)
                  </label>
                  <input 
                    type="text" 
                    placeholder="Accommodations Type"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("accommodationType")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Link to Accommodation
                  </label>
                  <input 
                    type="text" 
                    placeholder="Link to Accommodation"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("accommodationLink")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Accommodation Cost $
                  </label>
                  <input 
                    type="text" 
                    placeholder="Accommodation Cost $"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("accommodationCost")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Other Accommodation Link(s) - where did you want to stay, but didn't
                  </label>
                  <input 
                    type="text" 
                    placeholder="Other Accommodation Link(s)"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("otherAccommodationLinks")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Overall Accommodation Comments
                  </label>
                  <textarea 
                    rows={4}
                    placeholder="Overall Accommodation Comments"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("accommodationComments")}
                  ></textarea>
                </div>
              </div>
              
              <div className="flex justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab("travel")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("dining")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Next
                </button>
              </div>
            </TabsContent>
            
            <TabsContent value="dining" className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Restaurants Rating
                  </label>
                  <StarRating 
                    value={watch("restaurantRating") || 0}
                    onChange={(val) => setValue("restaurantRating", val)}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Restaurant Types
                  </label>
                  <input 
                    type="text" 
                    placeholder="Restaurant Types"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("restaurantTypes")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Restaurant Names and Links to Restaurants
                  </label>
                  
                  {restaurants.map((id, index) => (
                    <RestaurantRow 
                      key={id}
                      index={id}
                      register={register}
                      onRemove={() => removeRestaurantRow(index)}
                    />
                  ))}
                  
                  <button
                    type="button"
                    onClick={addRestaurantRow}
                    className="mt-2 text-sm text-purple-600 hover:text-purple-800"
                  >
                    + Add another restaurant
                  </button>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Best/Must Try Food
                  </label>
                  <input 
                    type="text" 
                    placeholder="Best/Must Try Food"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("bestFood")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Other Restaurant Option(s) that you didn't try, but wanted to
                  </label>
                  <input 
                    type="text" 
                    placeholder="Other Restaurant Option(s)"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("otherRestaurantOptions")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Overall Restaurant Comments
                  </label>
                  <textarea 
                    rows={4}
                    placeholder="Overall Restaurant Comments"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("restaurantComments")}
                  ></textarea>
                </div>
              </div>
              
              <div className="flex justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab("accommodation")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("transportation")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Next
                </button>
              </div>
            </TabsContent>
            
            <TabsContent value="transportation" className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Rental Car Rating
                  </label>
                  <StarRating 
                    value={watch("rentalCarRating") || 0}
                    onChange={(val) => setValue("rentalCarRating", val)}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Rental Car Company
                  </label>
                  <input 
                    type="text" 
                    placeholder="Rental Car Company"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("rentalCarCompany")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Rental Car Cost $
                  </label>
                  <input 
                    type="text" 
                    placeholder="Rental Car Cost $"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("rentalCarCost")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Quality of Car (Good, Optimal or Bad)
                  </label>
                  <input 
                    type="text" 
                    placeholder="Quality of Car"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("rentalCarQuality")}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Overall Rental Car Comments
                  </label>
                  <textarea 
                    rows={4}
                    placeholder="Overall Rental Car Comments"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("rentalCarComments")}
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Other Transportation Comment (train, subway, etc.)
                  </label>
                  <textarea 
                    rows={4}
                    placeholder="Other Transportation Comment"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("otherTransportation")}
                  ></textarea>
                </div>
              </div>
              
              <div className="flex justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab("dining")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("activities")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Next
                </button>
              </div>
            </TabsContent>
            
            <TabsContent value="activities" className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Excursions
                  </label>
                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <WysiwygToolbar textareaId="excursions" />
                    <textarea 
                      id="excursions"
                      rows={6}
                      placeholder="Excursions"
                      className="w-full border-0 p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      {...register("excursions")}
                    ></textarea>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Overall Comment
                  </label>
                  <textarea 
                    rows={4}
                    placeholder="Overall Comment"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    {...register("overallComment")}
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-slate-700 mb-1">
                    Select Category <span className="text-red-500">*</span>
                  </label>
                  <select 
                    id="category" 
                    className={`w-full border ${errors.category ? 'border-red-500' : 'border-slate-300'} rounded-lg p-2 focus:ring-2 focus:ring-purple-500 focus:border-purple-500`}
                    {...register("category")}
                  >
                    <option value="" disabled>Select a category</option>
                    {tripType === "future" ? (
                      <option value="future">Future Trip</option>
                    ) : (
                      <>
                        {tripCategories.map(category => (
                          <option key={category} value={category}>
                            {category.charAt(0).toUpperCase() + category.slice(1)}
                          </option>
                        ))}
                        {sharing && <option value="shared">Shared Trip</option>}
                      </>
                    )}
                  </select>
                  {errors.category && (
                    <div className="text-red-500 text-sm mt-1">{errors.category.message}</div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab("transportation")}
                  className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md"
                >
                  Previous
                </button>
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className={`bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-lg flex items-center ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Saving...
                    </>
                  ) : (
                    'Create Trip'
                  )}
                </button>
              </div>
            </TabsContent>
          </form>
        </Tabs>
      </div>
    </div>
  );
};

export default AddTrip;
