import React, { useState, useRef, useEffect } from 'react';
import { useLocation } from 'wouter';
import { 
  User, LogOut, Settings, CreditCard, 
  HelpCircle, Heart, Bell, Mail
} from 'lucide-react';

interface ProfileMenuProps {
  userName?: string;
  userImage?: string;
}

const ProfileMenu: React.FC<ProfileMenuProps> = ({ 
  userName = 'John Doe', 
  userImage 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [, setLocation] = useLocation();

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleLogout = () => {
    // Handle logout logic here
    console.log('Logging out...');
    setIsOpen(false);
    // Navigate to login page or home
    setLocation('/');
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Profile Button */}
      <button 
        className="flex items-center justify-center w-10 h-10 rounded-full overflow-hidden bg-purple-700 text-white focus:outline-none shadow-md border-2 border-white"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        {userImage ? (
          <img src={userImage} alt={userName} className="w-full h-full object-cover" />
        ) : (
          <span className="text-xl font-semibold">{userName.charAt(0)}</span>
        )}
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg overflow-hidden z-50 border border-gray-200">
          {/* Header */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center">
              <div className="flex-shrink-0 mr-3">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-purple-700 flex items-center justify-center text-white shadow border-2 border-purple-200">
                  {userImage ? (
                    <img src={userImage} alt={userName} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-xl font-semibold">{userName.charAt(0)}</span>
                  )}
                </div>
              </div>
              <div>
                <p className="font-semibold text-gray-800">{userName}</p>
                <p className="text-sm text-gray-500">john.doe@example.com</p>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="py-2 px-1">
            <div className="px-3 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Account
            </div>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/profile');
              }}
            >
              <User className="mr-2 h-4 w-4 text-gray-500" />
              <span>My Profile</span>
            </button>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/settings');
              }}
            >
              <Settings className="mr-2 h-4 w-4 text-gray-500" />
              <span>Account Settings</span>
            </button>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/billing');
              }}
            >
              <CreditCard className="mr-2 h-4 w-4 text-gray-500" />
              <span>Billing</span>
            </button>
          </div>

          <div className="py-2 px-1 border-t border-gray-200">
            <div className="px-3 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Preferences
            </div>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/favorites');
              }}
            >
              <Heart className="mr-2 h-4 w-4 text-gray-500" />
              <span>Saved Trips</span>
            </button>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/notifications');
              }}
            >
              <Bell className="mr-2 h-4 w-4 text-gray-500" />
              <span>Notifications</span>
              <span className="ml-auto bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs">5</span>
            </button>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/messages');
              }}
            >
              <Mail className="mr-2 h-4 w-4 text-gray-500" />
              <span>Messages</span>
              <span className="ml-auto bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs">3</span>
            </button>
          </div>

          <div className="py-2 px-1 border-t border-gray-200">
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-purple-50 rounded-md"
              onClick={() => {
                setIsOpen(false);
                setLocation('/help');
              }}
            >
              <HelpCircle className="mr-2 h-4 w-4 text-gray-500" />
              <span>Help & Support</span>
            </button>
            <button 
              className="flex items-center w-full px-3 py-2 text-left text-sm text-red-600 hover:bg-red-50 rounded-md"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4 text-red-500" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileMenu;