import { useLocation, Link } from "wouter";
import { 
  User, Settings, CreditCard, Heart, Bell, Mail, 
  HelpCircle, LogOut, Home, Compass, BarChart, Share2 
} from "lucide-react";

const Sidebar = () => {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  // Categories of sidebar items
  const mainNavItems = [
    { name: "Dashboard", path: "/", icon: <Home className="w-5 h-5" /> },
    { name: "My Trips", path: "/trips", icon: <Compass className="w-5 h-5" /> },
    { name: "Statistics", path: "/stats", icon: <BarChart className="w-5 h-5" /> },
    { name: "Shared Trips", path: "/shared-trips", icon: <Share2 className="w-5 h-5" /> },
  ];

  const accountItems = [
    { name: "My Profile", path: "/profile", icon: <User className="w-5 h-5" /> },
    { name: "Account Settings", path: "/settings", icon: <Settings className="w-5 h-5" /> },
    { name: "Billing", path: "/billing", icon: <CreditCard className="w-5 h-5" /> },
  ];

  const preferencesItems = [
    { name: "Saved Trips", path: "/favorites", icon: <Heart className="w-5 h-5" /> },
    { name: "Notifications", path: "/notifications", icon: <Bell className="w-5 h-5" />, badge: 5 },
    { name: "Messages", path: "/messages", icon: <Mail className="w-5 h-5" />, badge: 3 },
    { name: "Help & Support", path: "/help", icon: <HelpCircle className="w-5 h-5" /> },
  ];

  return (
    <aside className="bg-white shadow-lg md:w-64 w-full md:flex md:flex-col hidden md:fixed md:h-full z-10">
      <div className="p-6 overflow-y-auto flex-grow">
        {/* Main Navigation */}
        <div className="mb-8">
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Main</h2>
          <ul className="space-y-2">
            {mainNavItems.map((item) => (
              <li key={item.path}>
                <Link href={item.path}>
                  <a
                    className={`flex items-center px-3 py-2 rounded-md text-sm ${
                      isActive(item.path)
                        ? "bg-purple-100 text-purple-700 font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <span className={`mr-3 ${isActive(item.path) ? "text-purple-600" : "text-gray-500"}`}>
                      {item.icon}
                    </span>
                    {item.name}
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Account */}
        <div className="mb-8">
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Account</h2>
          <ul className="space-y-2">
            {accountItems.map((item) => (
              <li key={item.path}>
                <Link href={item.path}>
                  <a
                    className={`flex items-center px-3 py-2 rounded-md text-sm ${
                      isActive(item.path)
                        ? "bg-purple-100 text-purple-700 font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <span className={`mr-3 ${isActive(item.path) ? "text-purple-600" : "text-gray-500"}`}>
                      {item.icon}
                    </span>
                    {item.name}
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Preferences */}
        <div className="mb-8">
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Preferences</h2>
          <ul className="space-y-2">
            {preferencesItems.map((item) => (
              <li key={item.path}>
                <Link href={item.path}>
                  <a
                    className={`flex items-center px-3 py-2 rounded-md text-sm ${
                      isActive(item.path)
                        ? "bg-purple-100 text-purple-700 font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <span className={`mr-3 ${isActive(item.path) ? "text-purple-600" : "text-gray-500"}`}>
                      {item.icon}
                    </span>
                    {item.name}
                    {item.badge && (
                      <span className="ml-auto bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs">
                        {item.badge}
                      </span>
                    )}
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Logout Button */}
        <div className="mt-auto">
          <Link href="/">
            <a className="flex items-center px-3 py-2 rounded-md text-sm text-red-600 hover:bg-red-50">
              <LogOut className="w-5 h-5 mr-3 text-red-500" />
              Log Out
            </a>
          </Link>
        </div>
      </div>

      <div className="p-4 text-center text-xs text-slate-500 border-t border-gray-200">
        <div>About | Privacy Policy</div>
        <div>© 2025 TuckerTrips</div>
      </div>
    </aside>
  );
};

export default Sidebar;
