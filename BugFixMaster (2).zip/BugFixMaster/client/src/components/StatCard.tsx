interface StatCardProps {
  title: string;
  value: number | string;
  icon: string;
  color: "primary" | "secondary" | "accent" | "success";
}

const StatCard = ({ title, value, icon, color }: StatCardProps) => {
  const colorMap = {
    primary: "bg-primary bg-opacity-10 text-primary",
    secondary: "bg-secondary bg-opacity-10 text-secondary",
    accent: "bg-accent bg-opacity-10 text-accent",
    success: "bg-success bg-opacity-10 text-success"
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <div className="flex items-center">
        <div className={`rounded-full ${colorMap[color]} p-3 mr-4`}>
          <i className={`fas ${icon} text-xl`}></i>
        </div>
        <div>
          <p className="text-slate-500 text-sm">{title}</p>
          <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
        </div>
      </div>
    </div>
  );
};

export default StatCard;
