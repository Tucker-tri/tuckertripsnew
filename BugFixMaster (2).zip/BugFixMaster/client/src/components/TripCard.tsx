import { Trip } from "@shared/schema";
import { formatDateRange, getTimeAgo } from "@/lib/dateUtils";
import { Link } from "wouter";

interface TripCardProps {
  trip: Trip;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
  showActions?: boolean;
}

const TripCard = ({ trip, onEdit, onDelete, showActions = false }: TripCardProps) => {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "vacation": return "bg-accent";
      case "business": return "bg-primary";
      case "adventure": return "bg-secondary";
      case "family": return "bg-success";
      default: return "bg-slate-500";
    }
  };

  const categoryLabel = trip.category.charAt(0).toUpperCase() + trip.category.slice(1);
  const categoryColor = getCategoryColor(trip.category);
  const timeAgo = getTimeAgo(new Date(trip.createdAt));

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-40 bg-slate-200 relative">
        {trip.imageUrl ? (
          <img 
            src={trip.imageUrl} 
            alt={trip.destination} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-slate-100">
            <i className="fas fa-mountain text-4xl text-slate-400"></i>
          </div>
        )}
        <span className={`absolute top-2 right-2 ${categoryColor} text-white text-xs font-medium px-2 py-1 rounded`}>
          {categoryLabel}
        </span>
      </div>
      <div className="p-4">
        <h4 className="text-lg font-semibold text-slate-800 mb-1">{trip.destination}</h4>
        <p className="text-sm text-slate-500 mb-3">
          <i className="far fa-calendar mr-1"></i>
          {formatDateRange(new Date(trip.startDate), new Date(trip.endDate))}
        </p>
        <p className="text-sm text-slate-600 line-clamp-2 mb-3">
          {trip.description || "No description provided."}
        </p>
        <div className="flex justify-between items-center">
          {showActions ? (
            <div className="flex space-x-2">
              <button 
                onClick={() => onEdit && onEdit(trip.id)} 
                className="text-slate-500 hover:text-primary"
                title="Edit"
              >
                <i className="fas fa-edit"></i>
              </button>
              <button 
                onClick={() => onDelete && onDelete(trip.id)} 
                className="text-slate-500 hover:text-danger"
                title="Delete"
              >
                <i className="fas fa-trash"></i>
              </button>
            </div>
          ) : (
            <span className="text-xs text-slate-500">{timeAgo}</span>
          )}
          <Link href={`/trips/${trip.id}`}>
            <a className="text-primary hover:text-primary/80 font-medium text-sm">
              View Details
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default TripCard;
