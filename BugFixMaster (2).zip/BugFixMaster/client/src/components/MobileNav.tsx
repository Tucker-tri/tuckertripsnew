interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileNav = ({ isOpen, onClose }: MobileNavProps) => {
  return (
    <div className={`fixed inset-0 bg-slate-800 bg-opacity-50 z-20 ${isOpen ? '' : 'hidden'}`}>
      <div className="bg-white h-full w-64 p-4 shadow-lg">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-bold text-primary">TuckerTrips</h1>
          <button onClick={onClose} className="text-slate-700">
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <nav>
          <ul className="space-y-2">
            <li>
              <a 
                href="/" 
                onClick={onClose}
                className="block p-2 rounded-lg bg-primary bg-opacity-10 text-primary font-medium"
              >
                <i className="fas fa-home mr-2 w-5 text-center"></i>
                Dashboard
              </a>
            </li>
            <li>
              <a 
                href="/trips" 
                onClick={onClose}
                className="block p-2 rounded-lg text-slate-700 font-medium"
              >
                <i className="fas fa-suitcase mr-2 w-5 text-center"></i>
                My Trips
              </a>
            </li>
            <li>
              <a 
                href="/trips/add" 
                onClick={onClose}
                className="block p-2 rounded-lg text-slate-700 font-medium"
              >
                <i className="fas fa-plus mr-2 w-5 text-center"></i>
                Add New Trip
              </a>
            </li>
            <li>
              <a 
                href="/stats" 
                onClick={onClose}
                className="block p-2 rounded-lg text-slate-700 font-medium"
              >
                <i className="fas fa-chart-bar mr-2 w-5 text-center"></i>
                Statistics
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="block p-2 rounded-lg text-slate-700 font-medium"
              >
                <i className="fas fa-cog mr-2 w-5 text-center"></i>
                Settings
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="block p-2 rounded-lg text-slate-700 font-medium"
              >
                <i className="fas fa-question-circle mr-2 w-5 text-center"></i>
                Help
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default MobileNav;
