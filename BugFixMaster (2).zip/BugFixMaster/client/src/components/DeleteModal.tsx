interface DeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message?: string;
}

const DeleteModal = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  title = "Confirm Delete", 
  message = "Are you sure you want to delete this trip? This action cannot be undone."
}: DeleteModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-800 bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="text-center mb-6">
          <i className="fas fa-exclamation-triangle text-4xl text-danger mb-4"></i>
          <h3 className="text-xl font-bold text-slate-800">{title}</h3>
          <p className="text-slate-600 mt-2">{message}</p>
        </div>
        <div className="flex justify-end space-x-3">
          <button 
            onClick={onClose}
            className="bg-white border border-slate-300 text-slate-700 font-medium py-2 px-4 rounded-lg hover:bg-slate-50"
          >
            Cancel
          </button>
          <button 
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="bg-danger hover:bg-danger/90 text-white font-medium py-2 px-4 rounded-lg"
          >
            Delete Trip
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteModal;
