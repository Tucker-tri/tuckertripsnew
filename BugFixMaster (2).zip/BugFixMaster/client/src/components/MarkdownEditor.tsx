import React, { useState, useEffect, useRef, useCallback } from 'react';
import { marked } from 'marked';
import { 
  AlertTriangle, Bold, Italic, Underline, Hash, List, ListOrdered, 
  CheckSquare, Link, Image, Code, AlignLeft, FileText, Table,
  Type, Heading1, Heading2, Heading3, Quote, PanelRight, Search,
  Plus, FileImage, Calendar, CheckCircle2, MoreHorizontal
} from 'lucide-react';

interface MarkdownEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows?: number;
  id: string;
}

interface CommandMenuProps {
  isOpen: boolean;
  position: { top: number; left: number };
  onSelect: (command: string) => void;
  onClose: () => void;
  searchTerm: string;
}

// Command menu that appears when typing "/"
const CommandMenu: React.FC<CommandMenuProps> = ({ isOpen, position, onSelect, onClose, searchTerm }) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  // Define available commands
  const commands = [
    { id: 'text', name: 'Text', icon: <Type className="h-4 w-4" />, description: 'Just start writing with plain text' },
    { id: 'h1', name: 'Heading 1', icon: <Heading1 className="h-4 w-4" />, description: 'Big section heading' },
    { id: 'h2', name: 'Heading 2', icon: <Heading2 className="h-4 w-4" />, description: 'Medium section heading' },
    { id: 'h3', name: 'Heading 3', icon: <Heading3 className="h-4 w-4" />, description: 'Small section heading' },
    { id: 'bullet', name: 'Bullet List', icon: <List className="h-4 w-4" />, description: 'Create a bulleted list' },
    { id: 'numbered', name: 'Numbered List', icon: <ListOrdered className="h-4 w-4" />, description: 'Create a numbered list' },
    { id: 'todo', name: 'To-do List', icon: <CheckSquare className="h-4 w-4" />, description: 'Create a to-do list' },
    { id: 'quote', name: 'Quote', icon: <Quote className="h-4 w-4" />, description: 'Add a quote' },
    { id: 'divider', name: 'Divider', icon: <MoreHorizontal className="h-4 w-4" />, description: 'Add a divider' },
    { id: 'code', name: 'Code Block', icon: <Code className="h-4 w-4" />, description: 'Add a code block' },
    { id: 'image', name: 'Image', icon: <Image className="h-4 w-4" />, description: 'Add an image' },
    { id: 'table', name: 'Table', icon: <Table className="h-4 w-4" />, description: 'Add a table' },
  ];

  // Filter commands based on search term
  const filteredCommands = commands.filter(cmd => 
    searchTerm === '' || 
    cmd.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle keyboard navigation
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (!isOpen) return;
      
      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setActiveIndex(prev => (prev + 1) % filteredCommands.length);
          break;
        case 'ArrowUp':
          e.preventDefault();
          setActiveIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
          break;
        case 'Enter':
          e.preventDefault();
          if (filteredCommands[activeIndex]) {
            onSelect(filteredCommands[activeIndex].id);
          }
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onSelect, onClose, activeIndex, filteredCommands]);

  // Close when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  if (!isOpen) return null;

  return (
    <div 
      ref={menuRef}
      className="absolute z-50 bg-white rounded-md shadow-lg border border-gray-200 w-80 max-h-64 overflow-y-auto"
      style={{ top: position.top, left: position.left }}
    >
      <div className="p-2 border-b border-gray-200 flex items-center">
        <Search className="h-4 w-4 text-gray-500 mr-2" />
        <span className="text-sm text-gray-700">
          {searchTerm ? `Search: ${searchTerm}` : 'Basic blocks'}
        </span>
      </div>
      
      {filteredCommands.length > 0 ? (
        <div className="py-1">
          {filteredCommands.map((command, index) => (
            <div
              key={command.id}
              className={`px-3 py-2 flex items-center hover:bg-gray-100 cursor-pointer ${index === activeIndex ? 'bg-gray-100' : ''}`}
              onClick={() => onSelect(command.id)}
              onMouseEnter={() => setActiveIndex(index)}
            >
              <div className="bg-gray-100 rounded-md p-1 mr-2">
                {command.icon}
              </div>
              <div>
                <div className="font-medium text-sm">{command.name}</div>
                <div className="text-xs text-gray-500">{command.description}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-3 text-sm text-gray-500">No matching commands</div>
      )}
    </div>
  );
};

// Floating formatting menu (appears when text is selected)
const FloatingFormatMenu = ({ 
  isVisible, 
  position, 
  onFormatClick 
}: { 
  isVisible: boolean; 
  position: { top: number; left: number }; 
  onFormatClick: (format: string) => void 
}) => {
  if (!isVisible) return null;
  
  return (
    <div 
      className="absolute z-50 bg-white rounded-md shadow-lg border border-gray-200 flex items-center p-1"
      style={{ top: position.top, left: position.left }}
    >
      <button 
        type="button" 
        className="p-1 hover:bg-gray-100 rounded"
        onClick={() => onFormatClick('bold')}
        title="Bold"
      >
        <Bold className="h-4 w-4" />
      </button>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-100 rounded"
        onClick={() => onFormatClick('italic')}
        title="Italic"
      >
        <Italic className="h-4 w-4" />
      </button>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-100 rounded"
        onClick={() => onFormatClick('underline')}
        title="Underline"
      >
        <Underline className="h-4 w-4" />
      </button>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-100 rounded"
        onClick={() => onFormatClick('code')}
        title="Code"
      >
        <Code className="h-4 w-4" />
      </button>
      <button 
        type="button" 
        className="p-1 hover:bg-gray-100 rounded"
        onClick={() => onFormatClick('link')}
        title="Link"
      >
        <Link className="h-4 w-4" />
      </button>
    </div>
  );
};

const MarkdownEditor: React.FC<MarkdownEditorProps> = ({
  value,
  onChange,
  placeholder = 'Type / for commands',
  rows = 6,
  id
}) => {
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [htmlPreview, setHtmlPreview] = useState('');
  
  // For slash command menu
  const [commandMenuOpen, setCommandMenuOpen] = useState(false);
  const [commandMenuPosition, setCommandMenuPosition] = useState({ top: 0, left: 0 });
  const [searchTerm, setSearchTerm] = useState('');
  
  // For floating format menu
  const [formatMenuVisible, setFormatMenuVisible] = useState(false);
  const [formatMenuPosition, setFormatMenuPosition] = useState({ top: 0, left: 0 });
  
  // For line decorations (placeholders and +)
  const [cursorLine, setCursorLine] = useState(0);
  const editorRef = useRef<HTMLDivElement>(null);

  // Update preview when value changes
  useEffect(() => {
    try {
      let html = '';
      if (value) {
        html = marked.parse(value);
      }
      setHtmlPreview(typeof html === 'string' ? html : '');
    } catch (error) {
      console.error('Error parsing markdown:', error);
      setHtmlPreview('<div class="text-red-500">Error parsing markdown</div>');
    }
  }, [value]);

  const getCursorPosition = useCallback(() => {
    if (!textareaRef.current) return { top: 0, left: 0 };
    
    const textarea = textareaRef.current;
    const { selectionStart } = textarea;
    
    // Calculate line number
    const lines = textarea.value.substring(0, selectionStart).split('\n');
    const lineNumber = lines.length - 1;
    setCursorLine(lineNumber);
    
    // Get position within textarea
    const rect = textarea.getBoundingClientRect();
    const lineHeight = parseInt(getComputedStyle(textarea).lineHeight);
    
    const top = rect.top + window.scrollY + (lineHeight * lineNumber) - textarea.scrollTop;
    const left = rect.left + window.scrollX + 20; // Add offset
    
    return { top, left };
  }, []);

  // Opens the slash command menu
  const openCommandMenu = () => {
    if (!textareaRef.current) return;
    
    const position = getCursorPosition();
    setCommandMenuPosition(position);
    setCommandMenuOpen(true);
    setSearchTerm('');
  };

  // Handles text input and watches for slash command
  const handleTextareaInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
    
    const textarea = textareaRef.current;
    if (!textarea) return;
    
    const { selectionStart } = textarea;
    
    // Check if we just typed a slash at the beginning of a line or after a newline
    const lastChar = newValue[selectionStart - 1];
    const charBeforeLastChar = newValue[selectionStart - 2];
    
    if (lastChar === '/' && (selectionStart === 1 || charBeforeLastChar === '\n')) {
      openCommandMenu();
    }
    
    // Update search term if command menu is open
    if (commandMenuOpen) {
      const lines = newValue.substring(0, selectionStart).split('\n');
      const currentLine = lines[lines.length - 1];
      
      if (currentLine.startsWith('/')) {
        setSearchTerm(currentLine.substring(1));
      } else {
        setCommandMenuOpen(false);
      }
    }
  };

  // Check for selection to show formatting menu
  const handleTextareaSelect = () => {
    if (!textareaRef.current) return;
    
    const textarea = textareaRef.current;
    const { selectionStart, selectionEnd } = textarea;
    
    if (selectionStart !== selectionEnd) {
      // Text is selected, show format menu
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        
        setFormatMenuPosition({
          top: rect.top + window.scrollY - 40, // Position above the selection
          left: rect.left + window.scrollX + (rect.width / 2) - 60 // Center horizontally
        });
        
        setFormatMenuVisible(true);
      }
    } else {
      setFormatMenuVisible(false);
    }
  };

  const applyTextFormat = (formatter: (text: string) => string) => {
    if (!textareaRef.current) return;

    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    
    const formattedText = formatter(selectedText);
    
    // Insert the formatted text
    const newText = textarea.value.substring(0, start) + formattedText + textarea.value.substring(end);
    
    // Update the value
    onChange(newText);
    
    // Focus back on textarea after a short delay to allow React to re-render
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(
          start + formattedText.length,
          start + formattedText.length
        );
      }
    }, 0);
    
    // Hide the format menu
    setFormatMenuVisible(false);
  };

  // Markdown formatting functions
  const formatters = {
    bold: (text: string) => (text ? `**${text}**` : '****'),
    italic: (text: string) => (text ? `*${text}*` : '**'),
    underline: (text: string) => (text ? `__${text}__` : '____'),
    heading1: (text: string) => (text ? `# ${text}` : '# '),
    heading2: (text: string) => (text ? `## ${text}` : '## '),
    heading3: (text: string) => (text ? `### ${text}` : '### '),
    bulletList: (text: string) => (text ? text.split('\n').map(line => `- ${line}`).join('\n') : '- '),
    numberedList: (text: string) => (text ? text.split('\n').map((line, i) => `${i + 1}. ${line}`).join('\n') : '1. '),
    checkbox: (text: string) => (text ? `- [ ] ${text}` : '- [ ] '),
    link: (text: string) => (text ? `[${text}](url)` : '[](url)'),
    image: (text: string) => (text ? `![${text}](url)` : '![](url)'),
    code: (text: string) => (text ? `\`${text}\`` : '``'),
    codeBlock: (text: string) => (text ? `\`\`\`\n${text}\n\`\`\`` : '```\n```'),
    blockquote: (text: string) => (text ? text.split('\n').map(line => `> ${line}`).join('\n') : '> '),
    table: (text: string) => `| Header 1 | Header 2 | Header 3 |\n| --- | --- | --- |\n| Cell 1 | Cell 2 | Cell 3 |\n| Cell 4 | Cell 5 | Cell 6 |`,
    divider: () => '\n---\n'
  };

  // Handle command selection from slash menu
  const handleCommandSelect = (commandId: string) => {
    if (!textareaRef.current) return;
    
    const textarea = textareaRef.current;
    const { selectionStart } = textarea;
    
    // Find the start of the current line
    const text = textarea.value;
    const lines = text.substring(0, selectionStart).split('\n');
    const currentLineStart = selectionStart - lines[lines.length - 1].length;
    
    // Remove the slash command
    const newText = text.substring(0, currentLineStart) + text.substring(selectionStart);
    
    // Apply the selected command
    let commandText = '';
    switch (commandId) {
      case 'text':
        commandText = '';
        break;
      case 'h1':
        commandText = formatters.heading1('');
        break;
      case 'h2':
        commandText = formatters.heading2('');
        break;
      case 'h3':
        commandText = formatters.heading3('');
        break;
      case 'bullet':
        commandText = formatters.bulletList('');
        break;
      case 'numbered':
        commandText = formatters.numberedList('');
        break;
      case 'todo':
        commandText = formatters.checkbox('');
        break;
      case 'quote':
        commandText = formatters.blockquote('');
        break;
      case 'divider':
        commandText = formatters.divider();
        break;
      case 'code':
        commandText = formatters.codeBlock('');
        break;
      case 'image':
        commandText = formatters.image('');
        break;
      case 'table':
        commandText = formatters.table('');
        break;
      default:
        commandText = '';
    }
    
    // Update the text
    const finalText = newText.substring(0, currentLineStart) + commandText + newText.substring(currentLineStart);
    onChange(finalText);
    
    // Focus back on textarea
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newPosition = currentLineStart + commandText.length;
        textareaRef.current.setSelectionRange(newPosition, newPosition);
      }
    }, 0);
    
    // Close command menu
    setCommandMenuOpen(false);
  };

  return (
    <div className="border border-slate-200 rounded-lg overflow-hidden shadow-sm" ref={editorRef}>
      {/* Top Toolbar */}
      <div className="flex items-center justify-between space-x-1 border-b border-gray-200 p-1 bg-gray-50 rounded-t-md">
        <div className="flex items-center space-x-1">
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded"
            title="Page"
          >
            <FileText className="h-4 w-4 text-gray-600" />
          </button>
          <div className="border-r border-gray-300 h-6 mx-1"></div>
          
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded font-bold"
            onClick={() => applyTextFormat(formatters.bold)}
            title="Bold (Ctrl+B)"
          >
            <Bold className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded italic"
            onClick={() => applyTextFormat(formatters.italic)}
            title="Italic (Ctrl+I)"
          >
            <Italic className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded underline"
            onClick={() => applyTextFormat(formatters.underline)}
            title="Underline (Ctrl+U)"
          >
            <Underline className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Heading"
            onClick={() => applyTextFormat(formatters.heading1)}
          >
            <Hash className="h-4 w-4" />
          </button>
          
          <div className="border-r border-gray-300 h-6 mx-1"></div>
          
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Bullet List"
            onClick={() => applyTextFormat(formatters.bulletList)}
          >
            <List className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Numbered List"
            onClick={() => applyTextFormat(formatters.numberedList)}
          >
            <ListOrdered className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Checkbox"
            onClick={() => applyTextFormat(formatters.checkbox)}
          >
            <CheckSquare className="h-4 w-4" />
          </button>
          
          <div className="border-r border-gray-300 h-6 mx-1"></div>
          
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Link"
            onClick={() => applyTextFormat(formatters.link)}
          >
            <Link className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Image"
            onClick={() => applyTextFormat(formatters.image)}
          >
            <Image className="h-4 w-4" />
          </button>
          <button 
            type="button" 
            className="p-1 hover:bg-gray-200 rounded" 
            title="Code"
            onClick={() => applyTextFormat(formatters.code)}
          >
            <Code className="h-4 w-4" />
          </button>
        </div>
        
        <div>
          <button
            type="button"
            onClick={() => setIsPreviewMode(!isPreviewMode)}
            className={`text-xs px-3 py-1 rounded ${
              isPreviewMode ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'
            }`}
          >
            {isPreviewMode ? 'Edit' : 'Preview'}
          </button>
        </div>
      </div>
      
      {/* Editor/Preview Area */}
      <div className="relative">
        {/* Editor */}
        <div className={`${isPreviewMode ? 'hidden' : 'block'}`}>
          <textarea 
            id={id}
            ref={textareaRef}
            value={value}
            onChange={handleTextareaInput}
            onSelect={handleTextareaSelect}
            onKeyDown={(e) => {
              // Close format menu on escape
              if (e.key === 'Escape' && formatMenuVisible) {
                setFormatMenuVisible(false);
                e.preventDefault();
              }
            }}
            onBlur={() => {
              // Hide format menu when losing focus
              setTimeout(() => setFormatMenuVisible(false), 100);
            }}
            rows={rows}
            placeholder={placeholder}
            className="w-full border-0 p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none resize-none font-sans"
          ></textarea>
          
          {/* Add new block button (+ sign at the beginning of empty lines) */}
          {!isPreviewMode && value.split('\n')[cursorLine]?.trim() === '' && (
            <button
              type="button"
              className="absolute left-2 text-gray-400 hover:text-gray-600"
              style={{ top: `${cursorLine * 24 + 12}px` }} // Approximate line height
              onClick={openCommandMenu}
            >
              <Plus className="h-4 w-4" />
            </button>
          )}
          
          {/* Slash Command Menu */}
          <CommandMenu 
            isOpen={commandMenuOpen}
            position={commandMenuPosition}
            onSelect={handleCommandSelect}
            onClose={() => setCommandMenuOpen(false)}
            searchTerm={searchTerm}
          />
          
          {/* Floating Format Menu */}
          <FloatingFormatMenu 
            isVisible={formatMenuVisible}
            position={formatMenuPosition}
            onFormatClick={(format) => {
              switch (format) {
                case 'bold':
                  applyTextFormat(formatters.bold);
                  break;
                case 'italic':
                  applyTextFormat(formatters.italic);
                  break;
                case 'underline':
                  applyTextFormat(formatters.underline);
                  break;
                case 'code':
                  applyTextFormat(formatters.code);
                  break;
                case 'link':
                  applyTextFormat(formatters.link);
                  break;
              }
            }}
          />
        </div>
        
        {/* Preview */}
        <div 
          className={`${isPreviewMode ? 'block' : 'hidden'} p-3 min-h-[12rem] markdown-preview prose prose-sm max-w-none`}
          dangerouslySetInnerHTML={{ __html: htmlPreview }}
        ></div>
      </div>
      
      {/* Bottom tip */}
      <div className="border-t border-gray-200 p-2 bg-gray-50 text-xs text-gray-500 flex items-center">
        <div className="flex-1">Type <code className="bg-gray-200 px-1 rounded">/</code> for commands</div>
        <div>Use <code className="bg-gray-200 px-1 rounded">Markdown</code> for formatting</div>
      </div>
    </div>
  );
};

export default MarkdownEditor;