import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Trips from "@/pages/Trips";
import AddTrip from "@/pages/AddTrip";
import TripDetail from "@/pages/TripDetail";
import Statistics from "@/pages/Statistics";
import SharedTrips from "@/pages/SharedTrips";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";
import ProfileMenu from "./components/ProfileMenu";
import { Bell, Mail } from "lucide-react";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/trips" component={Trips} />
      <Route path="/trips/add" component={AddTrip} />
      <Route path="/trips/:id" component={TripDetail} />
      <Route path="/stats" component={Statistics} />
      <Route path="/shared-trips" component={SharedTrips} />
      <Route path="/profile" component={Profile} />
      <Route path="/settings" component={Settings} />
      <Route path="/favorites" component={Dashboard} />
      <Route path="/notifications" component={Dashboard} />
      <Route path="/messages" component={Dashboard} />
      <Route path="/help" component={Dashboard} />
      <Route path="/billing" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="h-screen flex flex-col app-container">
          {/* Top Navigation Bar */}
          <header className="bg-primary text-white py-2 px-4 flex justify-between items-center">
            <div className="flex items-center">
              <h1 className="text-xl font-bold flex items-center logo-gradient">
                <i className="fas fa-globe-americas mr-2"></i>
                TuckerTrips
              </h1>
            </div>
            
            <div className="flex-1 mx-6">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Search" 
                  className="w-full py-2 px-4 bg-primary-600 bg-opacity-30 rounded-md text-white placeholder-white placeholder-opacity-70 focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-40"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="text-white p-2 rounded-full hover:bg-primary-600 focus:outline-none">
                <Mail className="h-5 w-5" />
              </button>
              <button className="text-white p-2 rounded-full hover:bg-primary-600 focus:outline-none relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-0 right-0 bg-red-500 rounded-full w-2 h-2"></span>
              </button>
              <ProfileMenu userName="Laviezah" />
            </div>
          </header>
          
          <div className="flex flex-1 overflow-hidden">
            {/* Sidebar */}
            <Sidebar />
            
            {/* Main Content */}
            <div className="flex-1 md:ml-64 p-6 overflow-auto bg-slate-100">
              {/* User Welcome Card */}
              <div className="bg-white rounded-lg shadow p-4 mb-6">
                <div className="flex items-center">
                  <div className="text-amber-400 mr-2">
                    <i className="fas fa-moon"></i>
                  </div>
                  <div>
                    <h3 className="font-medium">Hi, Laviezah</h3>
                    <p className="text-sm text-slate-500">Good Evening!</p>
                  </div>
                </div>
              </div>
              
              {/* Active Users Card (Placeholder) */}
              <div className="bg-white rounded-lg shadow p-4 mb-6">
                <h3 className="font-medium mb-2">Active users</h3>
                {/* This would be populated with actual user data */}
              </div>
              
              <Router />
            </div>
          </div>
          
          {/* Mobile Menu */}
          <MobileNav isOpen={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
